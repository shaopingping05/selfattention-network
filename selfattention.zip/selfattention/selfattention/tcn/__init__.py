from tcn.tcn import TCN, compiled_tcn, tcn_full_summary  # noqa

__version__ = '3.5.0'
